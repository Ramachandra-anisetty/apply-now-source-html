<?php
defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!--Header section -->
<?php include("header.php"); ?>

<div class="pdf_sec">
    <section class="banner gallery_banner" style="background-image: url('<?php echo base_url("assets/images/header/7.jpg"); ?>')">
        <div class="banner_overlay">
            <div class="container-section">
                <h2>Non-Discrimination Policy</h2>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li class="breadcrumb-item active banner-title">Non-Discrimination Policy</li>
                </ul>
            </div>
        </div>
    </section>

    <div class="container-section nirf p-5 mb-5">
        <h5 class="font-weight-bold">Introduction</h5>

        <p>To foster an inclusive and respectful environment, GITAM Deemed to be University commits to preventing
        discrimination and promoting equal opportunities for all individuals, regardless of gender, gender identity,
        sexual orientation, or any other characteristic.</p>

        <h5 class="font-weight-bold"> Scope</h5>
        <p>This policy applies to all students, faculty, staff, and visitors within GITAM Deemed to be University.</p>

        <h5 class="font-weight-bold"> Non-Discrimination Against Women</h5>
        <ul>
            <li>Equal opportunities:Ensure equal access to education, employment, and resources.</li>
            <li>Safe environment: Prevent sexual harassment, stalking, and violence.</li>
            <li>Support services: Provide counseling, health services, and gender-sensitive infrastructure.
            </li>
        </ul>

        <h5 class="font-weight-bold"> Discrimination Policies for Transgender</h5>
        <ul>
            <li>Inclusive language: Use respectful and gender-neutral language.</li>
            <li>Gender identity recognition: Recognize and respect self-identified gender.</li>
            <li>Access to facilities: Provide accessible and safe restrooms, locker rooms, and housing.
            </li>
            <li>Support services: Offer counseling, medical services, and academic accommodations.</li>
        </ul>

        <h5 class="font-weight-bold"> Non-Discriminatory Admissions Policy</h5>
        <ul>
            <li>Equal opportunities: Admissions based on merit, regardless of gender, caste, religion, or
                disability.</li>
            <li>Inclusive criteria:Consider diverse backgrounds, experiences, and perspectives.</li>
            <li>No bias: Prohibit discrimination in admissions processes.</li>
        </ul>

        <h5 class="font-weight-bold"> Responsibilities</h5>
        <ul>
            <li>University Administration: Oversee policy implementation.</li>
            <li>Diversity and Inclusion Committee: Monitor progress and suggest improvements.</li>
            <li>Faculty and Staff:Promote inclusive practices.</li>
            <li>Students: Participate in creating a respectful environment.</li>
        </ul>

        <h5 class="font-weight-bold"> Monitoring and Evaluation</h5>
        <ul>
            <li>Regular surveys and feedback.</li>
            <li>Incident reporting and tracking.</li>
            <li>Annual reporting to university administration.</li>
        </ul>

        <h5 class="font-weight-bold"> Review and Revision</h5>
        <p>This policy will be reviewed and revised every 2 years or as needed.</p>


    </div>
</div>


<?php include("footer.php"); ?>