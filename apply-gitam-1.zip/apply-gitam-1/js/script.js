  
        // Move recruiters strip to below the carousel controls
        (function () {
          const recruiters = document.querySelector(".recruiters-section");
          const controls = document.querySelector(".placements-controls");
          if (recruiters && controls && controls.parentNode) {
            controls.parentNode.insertBefore(recruiters, controls.nextSibling);
          }
        })();

        (function () {
          const track = document.getElementById("placementsTrack");
          const stage = document.getElementById("placementsStage");
          const cards = Array.from(track.querySelectorAll(".pl-card"));
          const dotsContainer = document.getElementById("placementDots");
          const arrows = document.querySelectorAll(".pl-arr");
          const total = cards.length;
          let active = 4;
          let timer;

          cards.forEach((_, i) => {
            const dot = document.createElement("div");
            dot.className = "pl-dot";
            dot.addEventListener("click", () => setActive(i));
            dotsContainer.appendChild(dot);
          });
          const dots = Array.from(dotsContainer.children);

          const mobileMq = window.matchMedia("(max-width: 600px)");

          function update() {
            const isMobile = mobileMq.matches;
            cards.forEach((card, i) => {
              let offset = i - active;
              if (offset > total / 2) offset -= total;
              if (offset < -total / 2) offset += total;
              const abs = Math.abs(offset);

              if (isMobile) {
                const isCurrent = abs === 0;
                card.style.transform = "translateX(0) scale(1)";
                card.style.opacity = isCurrent ? "1" : "0";
                card.style.visibility = isCurrent ? "visible" : "hidden";
                card.style.filter = "none";
                card.style.zIndex = isCurrent ? "10" : "1";
                card.style.pointerEvents = isCurrent ? "auto" : "none";
                card.classList.toggle("is-active", isCurrent);
                return;
              }

              const direction = offset < 0 ? -1 : 1;
              let scale, opacity, brightness, x, z, rotateY;
              card.style.visibility = "visible";
              if (abs === 0) {
                scale = 1.18;
                opacity = 1;
                brightness = 1;
                x = 0;
                z = 10;
                rotateY = 0;
              } else if (abs === 1) {
                scale = 0.82;
                opacity = 0.82;
                brightness = 0.68;
                x = direction * 335;
                z = 7;
                rotateY = offset * -5;
              } else if (abs === 2) {
                scale = 0.64;
                opacity = 0.52;
                brightness = 0.48;
                x = direction * 590;
                z = 4;
                rotateY = offset * -6;
              } else {
                scale = 0.5;
                opacity = 0;
                brightness = 0.3;
                x = direction * 800;
                z = 1;
                rotateY = 0;
              }
              card.style.transform =
                "translateX(" +
                x +
                "px) scale(" +
                scale +
                ") rotateY(" +
                rotateY +
                "deg)";
              card.style.opacity = opacity;
              card.style.filter = "brightness(" + brightness + ")";
              card.style.zIndex = z;
              card.style.pointerEvents = abs > 2 ? "none" : "auto";
              card.classList.toggle("is-active", abs === 0);
            });
            dots.forEach((d, i) => d.classList.toggle("active", i === active));
          }

          function setActive(i) {
            active = ((i % total) + total) % total;
            update();
            restart();
          }

          function restart() {
            clearInterval(timer);
            timer = setInterval(() => setActive(active + 1), 2000);
          }

          cards.forEach((card, i) =>
            card.addEventListener("click", () => setActive(i)),
          );
          arrows.forEach((arr) =>
            arr.addEventListener("click", () =>
              setActive(active + parseInt(arr.dataset.dir, 10)),
            ),
          );
          stage.addEventListener("mouseenter", () => clearInterval(timer));
          stage.addEventListener("mouseleave", restart);
          mobileMq.addEventListener("change", update);

          update();
          restart();
        })();

        // ── Hostel tabs ──────────────────────────────────
        (function () {
          const tabs = document.querySelectorAll(".ht-tab");
          const panels = document.querySelectorAll(".ht-panel");

          tabs.forEach((tab) => {
            tab.addEventListener("click", () => {
              tabs.forEach((t) => t.classList.remove("ht-active"));
              panels.forEach((p) => p.classList.remove("ht-panel-active"));
              tab.classList.add("ht-active");
              const target = document.getElementById(
                "ht-panel-" + tab.dataset.tab,
              );
              if (target) target.classList.add("ht-panel-active");
            });
          });
        })();

        // ── Hostel tabs ──────────────────────────────────
        (function () {
          const tabs = document.querySelectorAll(".ht-tab-la");
          const panels = document.querySelectorAll(".ht-panel-la");

          tabs.forEach((tab) => {
            tab.addEventListener("click", () => {
              tabs.forEach((t) => t.classList.remove("ht-active-la"));
              panels.forEach((p) => p.classList.remove("ht-panel-active-la"));
              tab.classList.add("ht-active-la");
              const target = document.getElementById(
                "ht-panel-" + tab.dataset.tab + "-la",
              );
              if (target) target.classList.add("ht-panel-active-la");
            });
          });
        })();

        // ── Guest Speakers scroll-driven section ─────────────
        (function () {
          const section = document.getElementById("guestSpeakersSection");
          if (!section) return;
          const cards = Array.from(section.querySelectorAll(".gs-card"));
          const dots = Array.from(section.querySelectorAll(".gs-dot"));
          const counter = document.getElementById("gsCounter");
          const hint = document.getElementById("gsScrollHint");
          const total = cards.length;
          let current = -1;

          if (window.matchMedia("(max-width: 600px)").matches) {
            cards.forEach((c) => {
              c.style.opacity = 1;
              c.style.transform = "none";
            });
            return;
          }

          section.style.height = total * 40 + "vh";

          function show(idx) {
            if (idx === current) return;
            cards.forEach((c, i) => {
              c.classList.remove("gs-active", "gs-past");
              if (i === idx) c.classList.add("gs-active");
              else if (i < idx) c.classList.add("gs-past");
            });
            dots.forEach((d, i) =>
              d.classList.toggle("gs-dot-active", i === idx),
            );
            if (counter) counter.textContent = idx + 1 + " / " + total;
            if (hint && idx > 0) hint.classList.add("gs-hint-hide");
            current = idx;
          }

          function onScroll() {
            const rect = section.getBoundingClientRect();
            const scrollable = section.offsetHeight - window.innerHeight;
            if (scrollable <= 0) return;
            const progress = Math.max(0, Math.min(1, -rect.top / scrollable));
            show(Math.min(total - 1, Math.floor(progress * total)));
          }

          dots.forEach((d, i) => {
            d.addEventListener("click", () => {
              const scrollable = section.offsetHeight - window.innerHeight;
              const target = section.offsetTop + (i / total) * scrollable;
              window.scrollTo({
                top: target,
                behavior: "smooth",
              });
            });
          });

          onScroll();
          window.addEventListener("scroll", onScroll, {
            passive: true,
          });
        })();

        // ── Changemakers click carousel (no scroll-jacking) ──
        (function () {
          const section = document.getElementById("changemakersSection");
          if (!section) return;
          const cards = Array.from(section.querySelectorAll(".cm-card"));
          const dots = Array.from(section.querySelectorAll(".cm-dot"));
          const counter = document.getElementById("cmCounter");
          const prevBtn = document.getElementById("cmPrev");
          const nextBtn = document.getElementById("cmNext");
          const navLabel = document.getElementById("cmNavLabel");
          const progressFill = document.getElementById("cmProgressFill");
          const total = cards.length;
          let current = 0;
          let autoTimer = null;

          if (window.matchMedia("(max-width: 600px)").matches) {
            cards.forEach((c) => {
              c.style.opacity = 1;
              c.style.transform = "none";
            });
            return;
          }

          function show(idx, direction) {
            if (idx === current && direction !== undefined) return;
            cards.forEach((c, i) => {
              c.classList.remove("cm-active", "cm-past");
              if (i === idx) c.classList.add("cm-active");
              else if (i < idx) c.classList.add("cm-past");
            });
            dots.forEach((d, i) =>
              d.classList.toggle("cm-dot-active", i === idx),
            );
            if (counter) counter.textContent = idx + 1 + " / " + total;
            if (progressFill)
              progressFill.style.width = ((idx + 1) / total) * 100 + "%";
            current = idx;
          }

          function next() {
            show((current + 1) % total);
          }

          function prev() {
            show((current - 1 + total) % total);
          }

          function startAuto() {
            clearInterval(autoTimer);
            autoTimer = setInterval(next, 5000);
          }

          function resetAuto() {
            startAuto();
          }

          if (prevBtn)
            prevBtn.addEventListener("click", () => {
              prev();
              resetAuto();
              if (navLabel) navLabel.style.opacity = "0";
            });
          if (nextBtn)
            nextBtn.addEventListener("click", () => {
              next();
              resetAuto();
              if (navLabel) navLabel.style.opacity = "0";
            });

          dots.forEach((d, i) => {
            d.addEventListener("click", () => {
              show(i);
              resetAuto();
              if (navLabel) navLabel.style.opacity = "0";
            });
          });

          document.addEventListener("keydown", (e) => {
            if (!isInViewport(section)) return;
            if (e.key === "ArrowRight") {
              next();
              resetAuto();
            } else if (e.key === "ArrowLeft") {
              prev();
              resetAuto();
            }
          });

          function isInViewport(el) {
            const rect = el.getBoundingClientRect();
            return rect.top < window.innerHeight && rect.bottom > 0;
          }

          show(0);
          startAuto();
        })();

        // Mobile FAB — appears after hero CTA scrolls out of view
        (function () {
          const fab = document.getElementById("mobFab");
          const hero = document.querySelector(".hero");
          if (!fab || !hero) return;

          function onScroll() {
            const heroBottom = hero.getBoundingClientRect().bottom;
            if (heroBottom < 0) {
              fab.classList.add("mob-fab-visible");
            } else {
              fab.classList.remove("mob-fab-visible");
            }
          }
          window.addEventListener("scroll", onScroll, {
            passive: true,
          });
        })();

        // Bottom apply card — slides up when user nears the bottom of the page
        (function () {
          const card = document.getElementById("applyCard");
          const closeBtn = document.getElementById("applyCardClose");
          const pageNav = document.getElementById("page-nav");
          if (!card) return;

          let dismissed = false;

          function setCardVisible(visible) {
            if (visible) {
              card.classList.add("ac-visible");
              if (pageNav) pageNav.classList.add("pnav-card-active");
            } else {
              card.classList.remove("ac-visible");
              if (pageNav) pageNav.classList.remove("pnav-card-active");
            }
          }

          function onScroll() {
            if (dismissed) return;
            const scrolled = window.scrollY + window.innerHeight;
            const total = document.documentElement.scrollHeight;
            // Show only when user reaches the very bottom of the page
            setCardVisible(total - scrolled < 40);
          }

          if (closeBtn) {
            closeBtn.addEventListener("click", function () {
              dismissed = true;
              setCardVisible(false);
            });
          }

          window.addEventListener("scroll", onScroll, {
            passive: true,
          });
        })();

        // Explore Engage Enjoy — tab switcher
        (function () {
          const tabs = document.querySelectorAll(".eee-tab");
          const panels = document.querySelectorAll(".eee-panel");
          tabs.forEach(function (tab) {
            tab.addEventListener("click", function () {
              const target = tab.dataset.tab;
              event.preventDefault(); // prevent refresh/postback
              event.stopPropagation();
              tabs.forEach(function (t) {
                t.classList.remove("eee-tab-active");
                t.setAttribute("aria-selected", "false");
              });
              panels.forEach(function (p) {
                p.classList.remove("eee-panel-active");
              });
              tab.classList.add("eee-tab-active");
              tab.setAttribute("aria-selected", "true");
              const panel = document.querySelector(
                '[data-panel="' + target + '"]',
              );
              if (panel) panel.classList.add("eee-panel-active");
            });
          });
        })();
   



        (function () {
          const cards = document.querySelectorAll(".he-card");
          const touchMq = window.matchMedia(
            "(hover: none), (max-width: 600px)",
          );

          function isTouchMode() {
            return touchMq.matches;
          }

          cards.forEach((card) => {
            card.addEventListener("click", (e) => {
              if (!isTouchMode()) return;
              e.stopPropagation();
              const open = card.classList.contains("is-revealed");
              cards.forEach((c) => c.classList.remove("is-revealed"));
              if (!open) card.classList.add("is-revealed");
            });
          });

          document.addEventListener("click", (e) => {
            if (!isTouchMode()) return;
            if (!e.target.closest(".he-card")) {
              cards.forEach((c) => c.classList.remove("is-revealed"));
            }
          });

          touchMq.addEventListener("change", () => {
            cards.forEach((c) => c.classList.remove("is-revealed"));
          });
        })();
    


        (function () {
          const cards = document.querySelectorAll(".ec");
          const touchMq = window.matchMedia(
            "(hover: none), (max-width: 600px)",
          );

          function isTouchMode() {
            return touchMq.matches;
          }

          cards.forEach((card) => {
            card.addEventListener("click", (e) => {
              if (!isTouchMode()) return;
              e.stopPropagation();
              const open = card.classList.contains("is-revealed");
              cards.forEach((c) => c.classList.remove("is-revealed"));
              if (!open) card.classList.add("is-revealed");
            });
          });

          document.addEventListener("click", (e) => {
            if (!isTouchMode()) return;
            if (!e.target.closest(".ec")) {
              cards.forEach((c) => c.classList.remove("is-revealed"));
            }
          });

          touchMq.addEventListener("change", () => {
            cards.forEach((c) => c.classList.remove("is-revealed"));
          });
        })();
    


        (function () {
          const cards = document.querySelectorAll(".bt-card");
          const touchMq = window.matchMedia(
            "(hover: none), (max-width: 600px)",
          );

          function isTouchMode() {
            return touchMq.matches;
          }

          cards.forEach((card) => {
            card.addEventListener("click", (e) => {
              if (!isTouchMode()) return;
              e.preventDefault();
              e.stopPropagation();
              const open = card.classList.contains("is-revealed");
              cards.forEach((c) => {
                c.classList.remove("is-revealed");
                c.blur();
              });
              if (!open) card.classList.add("is-revealed");
            });
          });

          document.addEventListener("click", (e) => {
            if (!isTouchMode()) return;
            if (!e.target.closest(".bt-card")) {
              cards.forEach((c) => {
                c.classList.remove("is-revealed");
                c.blur();
              });
            }
          });

          touchMq.addEventListener("change", () => {
            cards.forEach((c) => c.classList.remove("is-revealed"));
          });
        })();
    

    //   <!-- MOBILE NAV SCRIPT -->
     
        (function () {
          /* ── Reliable cross-browser smooth scroll ── */
          function scrollToId(id) {
            var el = document.getElementById(id);
            if (!el) return;
            var top = el.getBoundingClientRect().top + window.pageYOffset - 64;
            window.scrollTo({
              top: Math.max(0, top),
              behavior: "smooth",
            });
          }

          /* ── More sheet ── */
          var moreBtn = document.getElementById("mob-more-btn");
          var sheet = document.getElementById("mob-sheet");
          var backdrop = document.getElementById("mob-sheet-backdrop");
          var closeBtn = document.getElementById("mob-sheet-close");

          function openSheet() {
            sheet.classList.add("open");
            backdrop.classList.add("open");
            document.body.style.overflow = "hidden";
          }

          function closeSheet() {
            sheet.classList.remove("open");
            backdrop.classList.remove("open");
            document.body.style.overflow = "";
          }

          moreBtn && moreBtn.addEventListener("click", openSheet);
          closeBtn && closeBtn.addEventListener("click", closeSheet);
          backdrop && backdrop.addEventListener("click", closeSheet);

          /* ── Tab bar buttons ── */
          document
            .querySelectorAll(".mnav-tab[data-target]")
            .forEach(function (btn) {
              btn.addEventListener("click", function () {
                scrollToId(btn.getAttribute("data-target"));
                document.querySelectorAll(".mnav-tab").forEach(function (t) {
                  t.classList.remove("active");
                });
                btn.classList.add("active");
              });
            });

          /* ── More sheet items ── */
          document
            .querySelectorAll(".msheet-item[data-target]")
            .forEach(function (btn) {
              btn.addEventListener("click", function () {
                var target = btn.getAttribute("data-target");
                closeSheet();
                /* wait for sheet to animate away before scrolling */
                setTimeout(function () {
                  scrollToId(target);
                }, 300);
              });
            });

          /* ── Auto-highlight active tab while scrolling ── */
          var tabTargets = [
            "sec-hero",
            "sec-campuses",
            "sec-placements",
            "sec-faculty",
          ];
          var tabObs = new IntersectionObserver(
            function (entries) {
              entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                  var id = entry.target.id;
                  document
                    .querySelectorAll(".mnav-tab[data-target]")
                    .forEach(function (t) {
                      t.classList.toggle(
                        "active",
                        t.getAttribute("data-target") === id,
                      );
                    });
                }
              });
            },
            {
              rootMargin: "-40% 0px -50% 0px",
              threshold: 0,
            },
          );

          tabTargets.forEach(function (id) {
            var el = document.getElementById(id);
            if (el) tabObs.observe(el);
          });
        })();
     



   

      (function () {
        var nav = document.getElementById("page-nav");

        if (!nav) return;

        var btns = nav.querySelectorAll(".pnav-btn");

        var activeId = null;
        var isManualScrolling = false;

        /* ---------- smooth scroll ---------- */

        function scrollToId(id) {
          var el = document.getElementById(id);

          if (!el) return;

          var top = el.getBoundingClientRect().top + window.pageYOffset - 64;

          window.scrollTo({
            top: Math.max(0, top),
            behavior: "smooth",
          });
        }

        /* ---------- click ---------- */

        btns.forEach(function (btn) {
          btn.addEventListener("click", function () {
            isManualScrolling = true;

            activeId = btn.getAttribute("data-target");

            updateActive();

            scrollToId(activeId);

            setTimeout(function () {
              isManualScrolling = false;
            }, 1200);
          });
        });

        /* ---------- collect ids ---------- */

        var sectionIdSet = {};

        Array.from(btns).forEach(function (btn) {
          var extra = btn.getAttribute("data-active-ids");

          if (extra) {
            extra.split(/\s+/).forEach(function (id) {
              if (id) sectionIdSet[id] = true;
            });
          } else {
            var primary = btn.getAttribute("data-target");

            if (primary) sectionIdSet[primary] = true;
          }
        });

        /* ---------- active button ---------- */

        function btnMatchesActive(btn, id) {
          if (!id) return false;

          if (btn.getAttribute("data-target") === id) return true;

          var extra = btn.getAttribute("data-active-ids");

          if (!extra) return false;

          return extra.split(/\s+/).indexOf(id) !== -1;
        }

        function updateActive() {
          btns.forEach(function (btn) {
            btn.classList.toggle("active", btnMatchesActive(btn, activeId));
          });
        }

        /* ---------- observer ---------- */

        var observer = new IntersectionObserver(
          function (entries) {
            if (isManualScrolling) return;

            var visible = entries
              .filter(function (entry) {
                return entry.isIntersecting;
              })
              .sort(function (a, b) {
                return b.intersectionRatio - a.intersectionRatio;
              });

            if (!visible.length) return;

            activeId = visible[0].target.dataset.navId || visible[0].target.id;

            updateActive();
          },

          {
            rootMargin: "-30% 0px -50% 0px",
            threshold: [0.1, 0.25, 0.5, 0.75],
          },
        );

        /* ---------- observe parent sections ---------- */

        Object.keys(sectionIdSet).forEach(function (id) {
          var el = document.getElementById(id);

          if (!el) return;

          var section = el.closest("section");

          if (section) {
            section.dataset.navId = id;

            observer.observe(section);
          } else {
            observer.observe(el);
          }
        });

        /* ---------- show nav ---------- */

        var whyEl = document.getElementById("sec-stats");

        if (whyEl && "IntersectionObserver" in window) {
          new IntersectionObserver(
            function (entries) {
              var entry = entries[0];

              var pastSection = entry.boundingClientRect.top < 0;

              nav.classList.toggle("pnav-visible", pastSection);
            },

            {
              threshold: 0,
            },
          ).observe(whyEl);
        }
      })();

      // ── Why GITAM Header — scroll-driven scale reveal ───────────────────────
      (function () {
        var header = document.getElementById("why-header");
        if (!header) return;
        var title = header.querySelector(".why-title");
        var eyebrow = header.querySelector(".why-eyebrow");
        var sub = header.querySelector(".why-sub");
        var glow = header; // ::before pseudo tracks class

        function clamp01(v) {
          return Math.max(0, Math.min(1, v));
        }

        function ease(t) {
          // ease-out cubic for a natural feel
          return 1 - Math.pow(1 - t, 3);
        }

        function update() {
          var rect = header.getBoundingClientRect();
          var vh = window.innerHeight;

          // progress: 0 when header top hits bottom of screen,
          //           1 when header top reaches 20% from top of viewport
          var raw = 1 - (rect.top - vh * 0.2) / (vh - vh * 0.2);
          var p = clamp01(raw);

          // title: scale 0.15 → 1, opacity 0 → 1
          if (title) {
            var s = 0.15 + ease(p) * 0.85;
            title.style.transform = "scale(" + s + ")";
            title.style.opacity = clamp01(p * 1.8);
          }

          // eyebrow: fades in from p = 0.25
          if (eyebrow) {
            var ep = clamp01((p - 0.25) / 0.5);
            eyebrow.style.opacity = ep;
            eyebrow.style.transform = "translateY(" + 8 * (1 - ep) + "px)";
          }

          // sub: fades in from p = 0.55
          if (sub) {
            var sp = clamp01((p - 0.55) / 0.45);
            sub.style.color = "rgba(255,255,255," + 0.55 * sp + ")";
          }

          // glow spotlight behind title
          if (p > 0.1) header.classList.add("revealed");
        }

        window.addEventListener("scroll", update, {
          passive: true,
        });
        update();
      })();

      // Chat FAB toggle
      (function () {
        var fab = document.getElementById("chat-fab");
        var trigger = document.getElementById("cfabTrigger");
        if (!trigger || !fab) return;
        trigger.addEventListener("click", function () {
          var open = fab.classList.toggle("open");
          trigger.setAttribute("aria-expanded", open ? "true" : "false");
        });
        document.addEventListener("click", function (e) {
          if (!fab.contains(e.target)) {
            fab.classList.remove("open");
            trigger.setAttribute("aria-expanded", "false");
          }
        });
      })();

      // Rotate student ambassador photos in Chat FAB
      (function () {
        var stack = document.querySelector(".cfab-student-stack");
        if (!stack) return;
        var photos = stack.querySelectorAll(".cfab-student-photo");
        if (photos.length < 2) return;
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches)
          return;
        var active = 0;
        setInterval(function () {
          photos[active].classList.remove("is-active");
          active = (active + 1) % photos.length;
          photos[active].classList.add("is-active");
        }, 1000);
      })();

      (function () {
        const swap = document.querySelector(".cfab-swap-icons");

        if (!swap) return;

        setInterval(function () {
          swap.classList.toggle("show-phone");
        }, 1500);
      })();

      document.querySelectorAll("style").forEach((s, i) => {
        if (s.textContent.includes("cfabSwapMsg")) {
          console.log("STYLE BLOCK", i);
          console.log(s.textContent);
        }
      });

      

//   <!-- EXPLORE PROGRAMS SCRIPT -->
  
      (function () {
        "use strict";

        /* ─────────────────────────────────── DATA ─────────────────────────────────── */
        var CAMPUS_NAMES = {
          
          vizag: "Visakhapatnam",
          hyd: "Hyderabad",
          blr: "Bengaluru",
        };

        var DATA = {
          ug: {
            "Engineering": {
              icon: "⚙️",
              programs: {
                "B.Tech Computer Science Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    hyd: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                    blr: { total: 195000, sc: 39000, s1: 78000, s2: 78000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Students scoring 50–60% must score over 42% in GAT and 75% in X Standard, or 55% (110/200) in GAT, or 85% in X Standard.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or KCET score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "Civil Engineering with Computer Application",
                      "Communication and Signal Processing",
                      "Electric Vehicle Technology",
                      "Robotics and Artificial Intelligence",
                      "VLSI Design and Technology",
                    ],
                    Management: [
                      "Consulting",
                      "Innovation and Entrepreneurship",
                    ],
                  },
                  fee: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE Main score required for admission.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong or unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Computer Science and Engineering (Artificial Intelligence and Machine Learning)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                    hyd: { total: 195000, sc: 39000, s1: 78000, s2: 78000 },
                    blr: { total: 205000, sc: 41000, s1: 82000, s2: 82000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Students scoring 50–60% must score over 42% in GAT and 75% in X Standard.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or KCET score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "Data Engineering",
                      "Cyber Security",
                      "Cloud Computing",
                      "Internet of Things",
                    ],
                    Management: [
                      "Consulting",
                      "Innovation and Entrepreneurship",
                    ],
                  },
                  fee: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE Main score required.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong or unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Computer Science and Engineering (Data Science)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                    hyd: { total: 195000, sc: 39000, s1: 78000, s2: 78000 },
                    blr: { total: 205000, sc: 41000, s1: 82000, s2: 82000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT score required for admission.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or KCET score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "Machine Learning",
                      "Big Data Analytics",
                      "Business Intelligence",
                      "Cloud Computing",
                    ],
                    Management: [
                      "Business Analytics",
                      "Innovation and Entrepreneurship",
                    ],
                  },
                  fee: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE Main score required.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Computer Science and Engineering (Cyber Security)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                    hyd: { total: 195000, sc: 39000, s1: 78000, s2: 78000 },
                    blr: { total: 205000, sc: 41000, s1: 82000, s2: 82000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT score required for admission.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or KCET score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "Machine Learning",
                      "Big Data Analytics",
                      "Business Intelligence",
                      "Cloud Computing",
                    ],
                    Management: [
                      "Business Analytics",
                      "Innovation and Entrepreneurship",
                    ],
                  },
                  fee: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with PCM from a recognized board. Valid GAT or JEE Main score required.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Electrical and Computer Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                    hyd: { total: 180000, sc: 36000, s1: 72000, s2: 72000 },
                    blr: { total: 190000, sc: 38000, s1: 76000, s2: 76000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "VLSI Design and Technology",
                      "Embedded Systems",
                      "Signal Processing",
                      "Communication Engineering",
                    ],
                  },
                  fee: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Electronics & Communication": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                    hyd: { total: 180000, sc: 36000, s1: 72000, s2: 72000 },
                    blr: { total: 190000, sc: 38000, s1: 76000, s2: 76000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "VLSI Design and Technology",
                      "Embedded Systems",
                      "Signal Processing",
                      "Communication Engineering",
                    ],
                  },
                  fee: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Electronics Engineering (VLSI Design and Technology)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                    hyd: { total: 180000, sc: 36000, s1: 72000, s2: 72000 },
                    blr: { total: 190000, sc: 38000, s1: 76000, s2: 76000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                    blr: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  minors: {
                    "Core Engineering": [
                      "VLSI Design and Technology",
                      "Embedded Systems",
                      "Signal Processing",
                      "Communication Engineering",
                    ],
                  },
                  fee: { total: 170000, sc: 34000, s1: 68000, s2: 68000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Mechanical Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Robotics and Artificial Intelligence": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Civil Engineering with Computer Application": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Computer Science and Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Computer Science and Engineering (Artificial Intelligence and Machine Learning)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Computer Science and Engineering (Cyber Security)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Computer Science and Engineering (Data Science)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "II Yr B.Tech. Electrical and Computer Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                 "II Yr B.Tech. Electrical and Computer Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                    hyd: { total: 175000, sc: 35000, s1: 70000, s2: 70000 },
                    blr: { total: 185000, sc: 37000, s1: 74000, s2: 74000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required.",
                    hyd: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT or JEE score required for admission.",
                  },
                  fee: { total: 165000, sc: 33000, s1: 66000, s2: 66000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Tech. Civil Engineering": {
                  dur: "4 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 160000, sc: 32000, s1: 64000, s2: 64000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics. Valid GAT score required for admission.",
                  },
                  fee: { total: 160000, sc: 32000, s1: 64000, s2: 64000 },
                  elig: "Minimum 50% or 5.0 CGPA in Intermediate/10+2 with Physics, Chemistry and Mathematics.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
              },
            },
            Architecture: {
              icon: "🏛️",
              programs: {
                "B.Arch (Bachelor of Architecture)": {
                  dur: "5 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 285000, sc: 57000, s1: 114000, s2: 114000 },
                    hyd: { total: 300000, sc: 60000, s1: 120000, s2: 120000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate marks in Intermediate/10+2 with Mathematics. Valid NATA score (minimum 70/200) required.",
                    hyd: "Minimum 50% aggregate marks in Intermediate/10+2 with Mathematics. Valid NATA score (minimum 70/200) or JEE Paper 2 required.",
                  },
                  fee: { total: 285000, sc: 57000, s1: 114000, s2: 114000 },
                  elig: "A minimum of 50% aggregate marks in Intermediate or 10+2 examination or 10+3 Diploma with Maths or equivalent grade and qualified in NATA with a minimum of 70 marks out of 200 or qualifying mark as prescribed by Council of Architecture.",
                  exam: "NATA",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong answer and unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking and Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
              },
            },
            Science: {
              icon: "🔬",
              programs: {
                "B.Sc Computer Science": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                    hyd: { total: 105000, sc: 21000, s1: 42000, s2: 42000 },
                    blr: { total: 115000, sc: 23000, s1: 46000, s2: 46000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Mathematics as one of the core subjects. Valid GAT score required.",
                    hyd: "Minimum 55% aggregate in 10+2 with Mathematics as one of the core subjects. Valid GAT or JEE score required.",
                    blr: "Minimum 55% aggregate in 10+2 with Mathematics as one of the core subjects. Valid GAT or KCET score required.",
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 60% aggregate in 10+2 with Mathematics as one of the core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
                "B.Sc Biotechnology": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                    hyd: { total: 105000, sc: 21000, s1: 42000, s2: 42000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Biology and Chemistry as core subjects. Valid GAT score required.",
                    hyd: "Minimum 55% aggregate in 10+2 with Biology and Chemistry as core subjects. Valid GAT or state entrance score required.",
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 60% aggregate in 10+2 with Biology and Chemistry as core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Biology and Chemistry",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Sc Chemistry": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                    hyd: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Chemistry as a core subject. Valid GAT score required.",
                    hyd: "Minimum 50% aggregate in 10+2 with Chemistry as a core subject. Valid GAT or state entrance score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Chemistry as a core subject.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Chemistry & Physics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Sc Physics": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Physics and Mathematics as core subjects. Valid GAT score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Physics and Mathematics as core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics & Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Sc Mathematics": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                    hyd: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Mathematics as a core subject. Valid GAT score required.",
                    hyd: "Minimum 50% aggregate in 10+2 with Mathematics as a core subject. Valid GAT or state entrance score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Mathematics as a core subject.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
              },
            },
            

            "Allied and Healthcare": {
              icon: "🔬",
              programs: {
                "Bachelor of Anaesthesia and Operation Theatre Technology": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                 
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Mathematics as one of the core subjects. Valid GAT score required.",
                  
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 60% aggregate in 10+2 with Mathematics as one of the core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
                "Bachelor of Dialysis Therapy Technology": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Biology and Chemistry as core subjects. Valid GAT score required.",
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 60% aggregate in 10+2 with Biology and Chemistry as core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Biology and Chemistry",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "Bachelor of Emergency Medical Technologist": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Chemistry as a core subject. Valid GAT score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Chemistry as a core subject.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Chemistry & Physics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "Bachelor of Medical Laboratory Sciences": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Physics and Mathematics as core subjects. Valid GAT score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Physics and Mathematics as core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics & Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "Bachelor of Medical Radiology and Imaging Technology": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Mathematics as a core subject. Valid GAT score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Mathematics as a core subject.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
                "Bachelor of Optometry": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Mathematics as a core subject. Valid GAT score required.",
                  },
                  fee: { total: 85000, sc: 17000, s1: 34000, s2: 34000 },
                  elig: "Minimum 55% aggregate in 10+2 with Mathematics as a core subject.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
              },
            },
            
            Education: {
              icon: "🏛️",
              programs: {
                "B.A. B.Ed": {
                  dur: "5 Years",
                  campuses: ["hyd"],
                  campusFee: {
                    hyd: { total: 300000, sc: 60000, s1: 120000, s2: 120000 },
                  },
                  campusElig: {
                    hyd: "Minimum 50% aggregate marks in Intermediate/10+2 with Mathematics. Valid NATA score (minimum 70/200) or JEE Paper 2 required.",
                  },
                  fee: { total: 285000, sc: 57000, s1: 114000, s2: 114000 },
                  elig: "A minimum of 50% aggregate marks in Intermediate or 10+2 examination or 10+3 Diploma with Maths or equivalent grade and qualified in NATA with a minimum of 70 marks out of 200 or qualifying mark as prescribed by Council of Architecture.",
                  exam: "NATA",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong answer and unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking and Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                "B.Sc. B.Ed": {
                  dur: "5 Years",
                  campuses: ["hyd"],
                  campusFee: {
                    hyd: { total: 300000, sc: 60000, s1: 120000, s2: 120000 },
                  },
                  campusElig: {
                    hyd: "Minimum 50% aggregate marks in Intermediate/10+2 with Mathematics. Valid NATA score (minimum 70/200) or JEE Paper 2 required.",
                  },
                  fee: { total: 285000, sc: 57000, s1: 114000, s2: 114000 },
                  elig: "A minimum of 50% aggregate marks in Intermediate or 10+2 examination or 10+3 Diploma with Maths or equivalent grade and qualified in NATA with a minimum of 70 marks out of 200 or qualifying mark as prescribed by Council of Architecture.",
                  exam: "NATA",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong answer and unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking and Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
              },
            },

            Physiotherapy: {
              icon: "🏛️",
              programs: {
                "Bachelor of Physiotherapy": {
                  dur: "5 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 300000, sc: 60000, s1: 120000, s2: 120000 },
                  },
                  campusElig: {
                    vizag: "Minimum 50% aggregate marks in Intermediate/10+2 with Mathematics. Valid NATA score (minimum 70/200) or JEE Paper 2 required.",
                  },
                  fee: { total: 285000, sc: 57000, s1: 114000, s2: 114000 },
                  elig: "A minimum of 50% aggregate marks in Intermediate or 10+2 examination or 10+3 Diploma with Maths or equivalent grade and qualified in NATA with a minimum of 70 marks out of 200 or qualifying mark as prescribed by Council of Architecture.",
                  exam: "NATA",
                  examIntro:
                    "The test consists of two sections with objective type (MCQ) questions. Each correct answer is awarded 2 marks. Wrong answer and unanswered questions receive nil marks.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking and Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Physics and Mathematics",
                      q: 60,
                      m: 120,
                      d: "90 Min",
                    },
                  ],
                },
                
              },
            },

            Management: {
              icon: "📊",
              programs: {
                "BBA (Bachelor of Business Administration)": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  campusFee: {
                    vizag: { total: 115000, sc: 23000, s1: 46000, s2: 46000 },
                    hyd: { total: 125000, sc: 25000, s1: 50000, s2: 50000 },
                    blr: { total: 135000, sc: 27000, s1: 54000, s2: 54000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 from any recognised board. No specific subject requirement. Valid GAT score required.",
                    hyd: "Minimum 50% aggregate in 10+2 from any recognised board. Valid GAT or state management entrance score required.",
                    blr: "Minimum 50% aggregate in 10+2 from any recognised board. Valid GAT or KCET score required.",
                  },
                  fee: { total: 115000, sc: 23000, s1: 46000, s2: 46000 },
                  elig: "Minimum 50% aggregate in 10+2 from any recognised board. No specific subject requirement.",
                  exam: "GITAM Management Test",
                  examIntro:
                    "The test evaluates aptitude, English proficiency, and logical reasoning through objective questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "English Language",
                      q: 30,
                      m: 60,
                      d: "30 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 30,
                      m: 60,
                      d: "30 Min",
                    },
                  ],
                },
                "B.Com (Bachelor of Commerce)": {
                  dur: "3 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                    hyd: { total: 105000, sc: 21000, s1: 42000, s2: 42000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 50% aggregate in 10+2 with Commerce or any stream from a recognised board. Valid GAT score required.",
                    hyd: "Minimum 50% aggregate in 10+2 with Commerce or any stream from a recognised board. Valid GAT or state entrance score required.",
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 50% aggregate in 10+2 with Commerce or any stream from a recognised board.",
                  exam: "GITAM Management Test",
                  examIntro:
                    "The test evaluates aptitude, English proficiency, and logical reasoning through objective questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "English Language",
                      q: 30,
                      m: 60,
                      d: "30 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 30,
                      m: 60,
                      d: "30 Min",
                    },
                  ],
                },
              },
            },
            Pharmacy: {
              icon: "💊",
              programs: {
                "B.Pharm (Bachelor of Pharmacy)": {
                  dur: "4 Years",
                  campuses: ["vizag", "hyd"],
                  campusFee: {
                    vizag: { total: 135000, sc: 27000, s1: 54000, s2: 54000 },
                    hyd: { total: 145000, sc: 29000, s1: 58000, s2: 58000 },
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Physics, Chemistry and Biology/Mathematics. Valid GAT score required.",
                    hyd: "Minimum 55% aggregate in 10+2 with Physics, Chemistry and Biology/Mathematics. Valid GAT or EAPCET score required.",
                  },
                  fee: { total: 135000, sc: 27000, s1: 54000, s2: 54000 },
                  elig: "Minimum 60% aggregate in 10+2 with Physics, Chemistry and Biology/Mathematics.",
                  exam: "GPAT / GSAT",
                  examIntro:
                    "The test evaluates pharmaceutical science knowledge through objective questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Pharmaceutical Sciences",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                    {
                      s: 2,
                      sub: "Chemistry & Biology",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                  ],
                },
                "Pharm D (Doctor of Pharmacy)": {
                  dur: "6 Years",
                  campuses: ["vizag"],
                  fee: { total: 160000, sc: 48000, s1: 80000, s2: 80000 },
                  elig: "Minimum 60% aggregate in 10+2 with Physics, Chemistry and Biology/Mathematics.",
                  exam: "GPAT / GSAT",
                  examIntro:
                    "The test evaluates pharmaceutical science knowledge through objective questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Pharmaceutical Sciences",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                    {
                      s: 2,
                      sub: "Chemistry & Biology",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                  ],
                },
              },
            },
            Law: {
              icon: "⚖️",
              programs: {
                "BBA LLB (Integrated)": {
                  dur: "5 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 130000, sc: 39000, s1: 65000, s2: 65000 },
                  elig: "Minimum 50% aggregate in 10+2 from any recognised board. Qualified in CLAT or GITAM Law Entrance Test.",
                  exam: "CLAT / GITAM Law Test",
                  examIntro:
                    "The test evaluates legal aptitude, English, general knowledge and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Legal Aptitude & Reasoning",
                      q: 35,
                      m: 70,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "English & General Knowledge",
                      q: 40,
                      m: 80,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Quantitative Techniques",
                      q: 25,
                      m: 50,
                      d: "20 Min",
                    },
                  ],
                },
                "B.Com LLB (Integrated)": {
                  dur: "5 Years",
                  campuses: ["vizag"],
                  fee: { total: 120000, sc: 36000, s1: 60000, s2: 60000 },
                  elig: "Minimum 50% aggregate in 10+2 with Commerce. Qualified in CLAT or GITAM Law Entrance Test.",
                  exam: "CLAT / GITAM Law Test",
                  examIntro:
                    "The test evaluates legal aptitude, English, general knowledge and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Legal Aptitude & Reasoning",
                      q: 35,
                      m: 70,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "English & General Knowledge",
                      q: 40,
                      m: 80,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Quantitative Techniques",
                      q: 25,
                      m: 50,
                      d: "20 Min",
                    },
                  ],
                },
              },
            },
            Nursing: {
              icon: "🏥",
              programs: {
                "B.Sc Nursing": {
                  dur: "4 Years",
                  campuses: ["vizag"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "Minimum 55% aggregate in 10+2 with Physics, Chemistry and Biology. Minimum age 17 years at time of admission.",
                  exam: "GSAT",
                  examIntro:
                    "The test evaluates knowledge in Biology, Chemistry and general science.",
                  secs: [
                    { s: 1, sub: "Biology", q: 50, m: 100, d: "60 Min" },
                    {
                      s: 2,
                      sub: "Chemistry & Physics",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
              },
            },
            "Humanities": {
              icon: "📚",
              programs: {
                "BA (Bachelor of Arts)": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  fee: { total: 90000, sc: 27000, s1: 45000, s2: 45000 },
                  elig: "Minimum 50% aggregate in 10+2 from any recognised board.",
                  exam: "GITAM Arts Test",
                  examIntro:
                    "The test evaluates general aptitude, English, and humanities knowledge.",
                  secs: [
                    {
                      s: 1,
                      sub: "General Aptitude",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "English & Humanities",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
                "BA Economics (Hons)": {
                  dur: "3 Years",
                  campuses: ["hyd"],
                  fee: { total: 90000, sc: 27000, s1: 45000, s2: 45000 },
                  elig: "Minimum 50% aggregate in 10+2, preferably with Economics or Mathematics.",
                  exam: "GITAM Arts Test",
                  examIntro:
                    "The test evaluates general aptitude, English, and humanities knowledge.",
                  secs: [
                    {
                      s: 1,
                      sub: "General Aptitude",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "English & Humanities",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
              },
            },
          },
          pg: {

            "Allied and Healthcare": {
              icon: "🔬",
              programs: {
                "Post Graduate Diploma in Health Care Simulation Technology": {
                  dur: "3 Years",
                  campuses: ["vizag"],
                  campusFee: {
                    vizag: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                   
                  },
                  campusElig: {
                    vizag:
                      "Minimum 55% aggregate in 10+2 with Mathematics as one of the core subjects. Valid GAT score required.",
                   
                  },
                  fee: { total: 95000, sc: 19000, s1: 38000, s2: 38000 },
                  elig: "Minimum 60% aggregate in 10+2 with Mathematics as one of the core subjects.",
                  exam: "GSAT",
                  examIntro:
                    "The test consists of two sections with objective type questions.",
                  secs: [
                    {
                      s: 1,
                      sub: "Critical Thinking & Problem Solving",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    { s: 2, sub: "Mathematics", q: 60, m: 120, d: "90 Min" },
                  ],
                },
               
               
               
                
              },
            },
            




            "Engineering": {
              icon: "⚙️",
              programs: {
                "M.Tech Computer Science Engineering": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  fee: { total: 160000, sc: 48000, s1: 80000, s2: 80000 },
                  elig: "B.Tech/BE in Computer Science, IT or related field with minimum 60% aggregate. Valid GATE score preferred.",
                  exam: "GATE / GITAM PG Test",
                  examIntro:
                    "The test evaluates advanced technical knowledge and problem-solving ability.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Technical Knowledge",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Mathematics & Aptitude",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Tech Artificial Intelligence & Data Science": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  fee: { total: 175000, sc: 52500, s1: 87500, s2: 87500 },
                  elig: "B.Tech/BE in any engineering or B.Sc/M.Sc in relevant science with minimum 60% aggregate.",
                  exam: "GATE / GITAM PG Test",
                  examIntro:
                    "The test evaluates advanced technical knowledge and problem-solving ability.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Technical Knowledge",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Mathematics & Aptitude",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Tech VLSI Design": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 155000, sc: 46500, s1: 77500, s2: 77500 },
                  elig: "B.Tech/BE in Electronics, ECE, EEE or related field with minimum 60% aggregate.",
                  exam: "GATE / GITAM PG Test",
                  examIntro:
                    "The test evaluates knowledge in Electronics and VLSI fundamentals.",
                  secs: [
                    {
                      s: 1,
                      sub: "Electronics & Circuits",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Mathematics & Aptitude",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Tech Power Systems": {
                  dur: "2 Years",
                  campuses: ["vizag"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "B.Tech/BE in Electrical Engineering or Power Engineering with minimum 60% aggregate.",
                  exam: "GATE / GITAM PG Test",
                  examIntro:
                    "The test evaluates knowledge in Electrical and Power systems.",
                  secs: [
                    {
                      s: 1,
                      sub: "Electrical Engineering",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Mathematics & Aptitude",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                  ],
                },
              },
            },
            Management: {
              icon: "📊",
              programs: {
                "MBA - General Management": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  fee: { total: 220000, sc: 66000, s1: 110000, s2: 110000 },
                  elig: "Bachelor's degree in any discipline with minimum 50% aggregate. Valid CAT / MAT / GMAT / GITAM MBA Test score.",
                  exam: "CAT / MAT / GITAM MBA Test",
                  examIntro:
                    "The test evaluates quantitative aptitude, verbal ability, data interpretation and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude & DI",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "Verbal Ability & RC",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 32,
                      m: 96,
                      d: "40 Min",
                    },
                  ],
                },
                "MBA Finance": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 220000, sc: 66000, s1: 110000, s2: 110000 },
                  elig: "Bachelor's degree in Commerce, Economics or any field with minimum 50% aggregate.",
                  exam: "CAT / MAT / GITAM MBA Test",
                  examIntro:
                    "The test evaluates quantitative aptitude, verbal ability, data interpretation and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude & DI",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "Verbal Ability & RC",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 32,
                      m: 96,
                      d: "40 Min",
                    },
                  ],
                },
                "MBA Marketing": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd", "blr"],
                  fee: { total: 220000, sc: 66000, s1: 110000, s2: 110000 },
                  elig: "Bachelor's degree in any discipline with minimum 50% aggregate.",
                  exam: "CAT / MAT / GITAM MBA Test",
                  examIntro:
                    "The test evaluates quantitative aptitude, verbal ability, data interpretation and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude & DI",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "Verbal Ability & RC",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 32,
                      m: 96,
                      d: "40 Min",
                    },
                  ],
                },
                "MBA Human Resources": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 220000, sc: 66000, s1: 110000, s2: 110000 },
                  elig: "Bachelor's degree in any discipline with minimum 50% aggregate.",
                  exam: "CAT / MAT / GITAM MBA Test",
                  examIntro:
                    "The test evaluates quantitative aptitude, verbal ability, data interpretation and logical reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Quantitative Aptitude & DI",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 2,
                      sub: "Verbal Ability & RC",
                      q: 34,
                      m: 102,
                      d: "40 Min",
                    },
                    {
                      s: 3,
                      sub: "Logical Reasoning",
                      q: 32,
                      m: 96,
                      d: "40 Min",
                    },
                  ],
                },
              },
            },
            Science: {
              icon: "🔬",
              programs: {
                "M.Sc Computer Science": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 120000, sc: 36000, s1: 60000, s2: 60000 },
                  elig: "B.Sc Computer Science or BCA or B.Tech with minimum 60% aggregate.",
                  exam: "GITAM PG Science Test",
                  examIntro:
                    "The test evaluates core science knowledge and aptitude.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Subject Knowledge",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Analytical Ability",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Sc Biotechnology": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 120000, sc: 36000, s1: 60000, s2: 60000 },
                  elig: "B.Sc Biotechnology or Life Sciences with minimum 60% aggregate.",
                  exam: "GITAM PG Science Test",
                  examIntro:
                    "The test evaluates core life science knowledge and aptitude.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Subject Knowledge",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Analytical Ability",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Sc Chemistry": {
                  dur: "2 Years",
                  campuses: ["vizag"],
                  fee: { total: 110000, sc: 33000, s1: 55000, s2: 55000 },
                  elig: "B.Sc Chemistry with minimum 60% aggregate.",
                  exam: "GITAM PG Science Test",
                  examIntro:
                    "The test evaluates chemistry knowledge and analytical ability.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Subject Knowledge",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Analytical Ability",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
                "M.Sc Mathematics": {
                  dur: "2 Years",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 110000, sc: 33000, s1: 55000, s2: 55000 },
                  elig: "B.Sc Mathematics with minimum 60% aggregate.",
                  exam: "GITAM PG Science Test",
                  examIntro:
                    "The test evaluates mathematical knowledge and analytical ability.",
                  secs: [
                    {
                      s: 1,
                      sub: "Core Subject Knowledge",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                    {
                      s: 2,
                      sub: "Analytical Ability",
                      q: 50,
                      m: 100,
                      d: "60 Min",
                    },
                  ],
                },
              },
            },
            Pharmacy: {
              icon: "💊",
              programs: {
                "M.Pharm Pharmaceutics": {
                  dur: "2 Years",
                  campuses: ["vizag"],
                  fee: { total: 160000, sc: 48000, s1: 80000, s2: 80000 },
                  elig: "B.Pharm with minimum 60% aggregate. Valid GPAT score preferred.",
                  exam: "GPAT / GITAM PG Pharm Test",
                  examIntro:
                    "The test evaluates advanced pharmaceutical science knowledge.",
                  secs: [
                    {
                      s: 1,
                      sub: "Pharmaceutical Sciences",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                    {
                      s: 2,
                      sub: "Chemistry & Biology",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                  ],
                },
                "M.Pharm Pharmacology": {
                  dur: "2 Years",
                  campuses: ["vizag"],
                  fee: { total: 160000, sc: 48000, s1: 80000, s2: 80000 },
                  elig: "B.Pharm with minimum 60% aggregate. Valid GPAT score preferred.",
                  exam: "GPAT / GITAM PG Pharm Test",
                  examIntro:
                    "The test evaluates advanced pharmacology knowledge.",
                  secs: [
                    {
                      s: 1,
                      sub: "Pharmaceutical Sciences",
                      q: 50,
                      m: 100,
                      d: "75 Min",
                    },
                    { s: 2, sub: "Pharmacology", q: 50, m: 100, d: "75 Min" },
                  ],
                },
              },
            },
            Architecture: {
              icon: "🏛️",
              programs: {
                "M.Arch (Master of Architecture)": {
                  dur: "2 Years",
                  campuses: ["vizag"],
                  fee: { total: 200000, sc: 60000, s1: 100000, s2: 100000 },
                  elig: "B.Arch with minimum 55% aggregate. Valid GATE score or equivalent preferred.",
                  exam: "GATE / GITAM Arch Test",
                  examIntro:
                    "The test evaluates advanced architectural design and technical knowledge.",
                  secs: [
                    { s: 1, sub: "Design & Theory", q: 40, m: 80, d: "60 Min" },
                    {
                      s: 2,
                      sub: "Technical & Construction",
                      q: 40,
                      m: 80,
                      d: "60 Min",
                    },
                  ],
                },
              },
            },
            Law: {
              icon: "⚖️",
              programs: {
                "LLM (Master of Laws)": {
                  dur: "1 Year",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
              },
            },
            Medical: {
              icon: "⚖️",
              programs: {
                "MD (Anaesthesiology)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Community Medicine)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Dermatology,Venerology & Leprosy)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (General Medicine)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Paediatrics)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Pathology)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Psychiatry)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Radio Diagnosis)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MD (Respiratory Medicine)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MS (General Surgery)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MS (Obstetrics & Gynecology)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MS (Ophthalmology)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MS (Orthopedics)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "MS (Otorhinolaryngology)": {
                  dur: "1 Year",
                  campuses: ["vizag" ],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
              },
            },
            Humanities: {
              icon: "⚖️",
              programs: {
                "M.A. Applied Psychology": {
                  dur: "1 Year",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "M.A. Economics": {
                  dur: "1 Year",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
                "M.A. English": {
                  dur: "1 Year",
                  campuses: ["vizag", "hyd"],
                  fee: { total: 150000, sc: 45000, s1: 75000, s2: 75000 },
                  elig: "LLB or any equivalent law degree with minimum 55% aggregate.",
                  exam: "CLAT PG / GITAM Law Test",
                  examIntro:
                    "The test evaluates advanced legal knowledge and reasoning.",
                  secs: [
                    {
                      s: 1,
                      sub: "Constitutional & Administrative Law",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                    {
                      s: 2,
                      sub: "Legal Reasoning & Analysis",
                      q: 40,
                      m: 80,
                      d: "45 Min",
                    },
                  ],
                },
              },
            },
          },
        };

        /* ─────────────────────────────── STATE ──────────────────────────────────── */
        var state = {
          level: "ug",
          disc: "",
          campuses: [],
          selectedProg: null,
          selectedProgName: "",
        };

        /* ─────────────────────────────── HELPERS ────────────────────────────────── */
        function fmt(n) {
          return "\u20B9\u202F" + n.toLocaleString("en-IN");
        }

        function getDisciplines(level) {
          var allDiscs = DATA[level];
          return allDiscs ? Object.keys(allDiscs).sort() : [];
        }

        function getAvailableCampuses() {
          if (!state.disc) return ["vizag", "hyd", "blr"];
          var disc = DATA[state.level] && DATA[state.level][state.disc];
          if (!disc) return ["vizag", "hyd", "blr"];
          var campusSet = {};
          Object.keys(disc.programs).forEach(function (pName) {
            disc.programs[pName].campuses.forEach(function (c) {
              campusSet[c] = true;
            });
          });
          return ["vizag", "hyd", "blr"].filter(function (c) {
            return campusSet[c];
          });
        }

        function getFilteredPrograms() {
          if (!state.disc || !state.campuses.length) return {};
          var disc = DATA[state.level] && DATA[state.level][state.disc];
          if (!disc) return {};
          var available = getAvailableCampuses();
          var activeCampuses = state.campuses.filter(function (c) {
            return available.indexOf(c) !== -1;
          });
          if (!activeCampuses.length) return {};
          var filtered = {};
          Object.keys(disc.programs).forEach(function (pName) {
            var p = disc.programs[pName];
            var match = p.campuses.some(function (c) {
              return activeCampuses.indexOf(c) !== -1;
            });
            if (match) filtered[pName] = p;
          });
          return filtered;
        }

        /* ─────────────────────────────── POPULATE DISCIPLINES ────────────────────── */
        function populateDiscs() {
          var sel = document.getElementById("epDiscSelect");
          if (!sel) return;
          sel.innerHTML =
            '<option value="" selected>Select a discipline</option>';
          getDisciplines(state.level).forEach(function (d) {
            var opt = document.createElement("option");
            opt.value = d;
            opt.textContent = d;
            sel.appendChild(opt);
          });
        }

        /* ─────────────────────────────── UPDATE CAMPUS AVAILABILITY ───────────── */
        function updateCampusAvailability() {
          var campusGroup = document.getElementById("epCampusGroup");
          if (campusGroup) {
            campusGroup.classList.toggle("ep-enabled", !!state.disc);
          }
          if (!state.disc) return;
          var available = getAvailableCampuses();
          document.querySelectorAll(".ep-campus-chk").forEach(function (chk) {
            var c = chk.value;
            var ok = available.indexOf(c) !== -1;
            chk.disabled = !ok;
            if (!ok) {
              chk.checked = false;
              state.campuses = state.campuses.filter(function (x) {
                return x !== c;
              });
            }
          });
        }

        /* ─────────────────────────────── RENDER PROGRAM LIST ─────────────────────── */
     
        var CAMPUS_LABELS = {
          vizag: "Visakhapatnam",
          hyd: "Hyderabad",
          blr: "Bengaluru",
        };
        var CAMPUS_ORDER = ["blr", "hyd", "vizag"];

        function renderProgList() {
          var pg = document.getElementById("epProgGroup");
          if (!pg) return;
          pg.innerHTML = "";
          if (!state.disc) {
            pg.classList.remove("ep-enabled");
            return;
          }
          if (!state.campuses.length) {
            pg.classList.remove("ep-enabled");
            pg.innerHTML =
              '<span style="color:rgba(255,255,255,0.5);font-size:13px;">Select a campus to view programmes</span>';
            return;
          }
          var programs = getFilteredPrograms();
          var keys = Object.keys(programs);
          pg.classList.add("ep-enabled");
          if (!keys.length) {
            pg.innerHTML =
              '<span style="color:rgba(255,255,255,0.5);font-size:13px;">No programmes available at the selected campus(es)</span>';
            return;
          }
          if (!state.selectedProgName || !programs[state.selectedProgName]) {
            state.selectedProgName = keys[0];
          }

          CAMPUS_ORDER.forEach(function (c) {
            if (state.campuses.indexOf(c) === -1) return;
            var campusProgs = keys.filter(function (pName) {
              return programs[pName].campuses.indexOf(c) !== -1;
            });
            if (!campusProgs.length) return;

            var group = document.createElement("div");
            group.className = "ep-prog-campus-group";

            var hd = document.createElement("div");
            hd.className = "ep-prog-campus-hd";
            hd.textContent = CAMPUS_LABELS[c] || c
            group.appendChild(hd);

            campusProgs.forEach(function (pName) {
              var div = document.createElement("div");
              div.className =
                "ep-prog-item" +
                (state.selectedProgName === pName ? " ep-active" : "");
              div.textContent = pName;
              div.setAttribute("data-name", pName);
              div.addEventListener("click", function () {
                state.selectedProgName = pName;
                renderProgList();
                renderResults();
              });
              group.appendChild(div);
            });

            pg.appendChild(group);
          });
            updateProgScrollHint();
                requestAnimationFrame(updateProgScrollHint);
                }
                function updateProgScrollHint() {
                var pg = document.getElementById("epProgGroup");
                var wrap = pg && pg.closest(".ep-prog-scroll-wrap");
                if (!wrap || !pg) return;
                var hasScroll = pg.scrollHeight > pg.clientHeight + 2;
                var atBottom =
                    pg.scrollTop + pg.clientHeight >= pg.scrollHeight - 8;
                wrap.classList.toggle("ep-has-scroll", hasScroll);
                wrap.classList.toggle("ep-at-bottom", hasScroll && atBottom);
                }

        /* ─────────────────────────────── BUILD RESULT BLOCK ─────────────────────── */
     

        function buildCampusCards(pData, activeCampuses) {
          // Show only selected campuses; fall back to all available for this program
          var pool =
            activeCampuses && activeCampuses.length
              ? activeCampuses.filter(function (c) {
                  return pData.campuses.indexOf(c) !== -1;
                })
              : pData.campuses;
          var campuses = pool.length ? pool : pData.campuses;
          var html = "";

          html += '<div class="ep-campus-grid">';

          campuses.forEach(function (c) {
            var fee = pData.campusFee ? pData.campusFee[c] : pData.fee;
            var elig = pData.campusElig ? pData.campusElig[c] : pData.elig;
            var effectiveFee = fee.total - fee.sc;

            html += '<div class="ep-campus-card">';
            html +=
              '<div class="ep-campus-card-header">' +
              CAMPUS_LABELS[c] +
              "</div>";
            html += '<div class="ep-campus-card-body">';

            // Fee structure label
            html += '<div class="ep-cc-section-label">Fee Structure</div>';
            html += '<div class="ep-cc-fee-row">';
            html +=
              "Program fee <strong>" +
              fmt(fee.total) +
              "/-</strong>&nbsp; | &nbsp;Scholarship <strong>" +
              fmt(fee.sc) +
              "/-</strong>&nbsp; | &nbsp;Effective fee <strong>" +
              fmt(effectiveFee) +
              "/-</strong>";
            html += "</div>";

            // Semester box
            html += '<div class="ep-cc-fee-box">';
            html +=
              '<div class="ep-cc-fee-box-label">Semester Wise (For First Year)</div>';
            html += '<div class="ep-cc-sems">';
            html +=
              '<div><div class="ep-cc-sem-label">Semester 1</div><div class="ep-cc-sem-val">' +
              fmt(fee.s1) +
              "</div></div>";
            html +=
              '<div><div class="ep-cc-sem-label">Semester 2</div><div class="ep-cc-sem-val">' +
              fmt(fee.s2) +
              "</div></div>";
            html += "</div></div>";

            // Note
           

             // Eligibility
            html +=
              '<div class="ep-cc-section-label ep-cc-mt">Eligibility</div>';
            html += '<p class="ep-cc-elig">' + elig + "</p>";

            html += "</div></div>";
          });

          html += "</div>";
          html +=
            '<div class="ep-fee-inc">Tuition fees will increase by 5% to 8% in the subsequent years.</div>';
          html +=
            '<div class="ep-cc-note ep-fee-common-note"><strong>Note:</strong> Students who choose to pay the full first-year fee as a single annual payment will be eligible for a 3% discount on the total payable amount.</div>';
          return html;
        }

        function buildResultBlock(pName, pData, activeCampuses) {
          var rows = pData.secs
            .map(function (sec) {
              return (
                "<tr><td>" +
                sec.s +
                "</td><td>" +
                sec.sub +
                "</td><td>" +
                sec.q +
                "</td><td>" +
                sec.m +
                "</td><td>" +
                sec.d +
                "</td></tr>"
              );
            })
            .join("");

          var html = '<div class="ep-detail-block">';

          // Title row — name + campus pills showing which campuses offer this programme
          var campusPills = pData.campuses
            .map(function (c) {
              return (
                '<span class="ep-title-campus-tag">' +
                (CAMPUS_LABELS[c] || c) +
                "</span>"
              );
            })
            .join("");
          html +=
            '<div class="ep-detail-title">' +
            pName +
            '<span class="ep-title-campuses">' +
            campusPills +
            "</span>" +
            "</div>";

          // Minors section (if present)
          if (pData.minors && Object.keys(pData.minors).length) {
            var shortName = pName
              .replace("B.Tech ", "")
              .replace("B.Sc ", "")
              .replace("B.Arch ", "")
              .replace("BBA ", "")
              .replace("B.Com ", "")
              .replace("B.Pharm ", "");
            html += '<div class="ep-minors-section">';
            html +=
              '<p class="ep-minors-intro">For ' +
              shortName +
              " major, here are the minors you can choose from</p>";
            Object.keys(pData.minors).forEach(function (cat) {
              html += '<div class="ep-minor-row">';
              html += '<div class="ep-minor-cat">' + cat + "</div>";
              html += '<div class="ep-minor-tags">';
              pData.minors[cat].forEach(function (m) {
                html += '<span class="ep-minor-tag">' + m + "</span>";
              });
              html += "</div></div>";
            });
            html += "</div>";
          }

          // Campus comparison cards
          html += buildCampusCards(pData, activeCampuses);

          // Exam pattern
          html +=
            '<div class="ep-detail-grid" style="margin-top:28px">' +
            "<div>" +
            '<div class="ep-section-title">Exam pattern</div>' +
            '<p class="ep-detail-text">' +
            pData.examIntro +
            "</p>" +
            '<div class="ep-exam-wrap"><table class="ep-exam-tbl">' +
            "<thead><tr><th>Section</th><th>Subject</th><th>Questions</th><th>Total marks</th><th>Duration</th></tr></thead>" +
            "<tbody>" +
            rows +
            "</tbody>" +
            "</table></div>" +
            "</div>" +
            "<div>" +
            '<div class="ep-section-title">Take a demo test</div>' +
            '<div class="ep-demo-form">' +
            '<input type="text" placeholder="Enter name"/>' +
            '<div class="ep-demo-row">' +
            '<input type="text" placeholder="Enter mobile no."/>' +
            '<input type="email" placeholder="Enter email ID"/>' +
            "</div>" +
            '<button class="ep-demo-btn">Get demo test</button>' +
            "</div>" +
            '<div class="ep-section-title ep-mt">Syllabus</div>' +
            '<a href="#" class="ep-syllabus-link"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Click Here to Download the syllabus</a>' +
            "</div>" +
            "</div>";

          html += "</div>";
          return html;
        }

        /* ─────────────────────────────── RENDER RESULTS ─────────────────────────── */
            function renderResults() {
        var area = document.getElementById("epResultsArea");
        if (!area) return;
        if (!state.selectedProgName || !state.disc || !state.campuses.length) {
          if (state.disc && state.campuses.length) {
            area.innerHTML = '<div style="text-align: center; padding: 40px 24px; color: rgba(255, 255, 255, 0.45); font-size: 13.5px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px; font-weight: 500;">Select a programme from the list to view its fee structures, campus details, and eligibility.</div>';
          } else {
            area.innerHTML = "";
          }
          return;
        }
        var disc = DATA[state.level] && DATA[state.level][state.disc];
        if (!disc || !disc.programs[state.selectedProgName]) {
          area.innerHTML = "";
          return;
        }
        var available = getAvailableCampuses();
        var activeCampuses = state.campuses.filter(function (c) {
          return available.indexOf(c) !== -1;
        });
        area.innerHTML = buildResultBlock(
          state.selectedProgName,
          disc.programs[state.selectedProgName],
          activeCampuses,
        );
      }

        /* ─────────────────────────────── EVENT LISTENERS ─────────────────────────── */
        document
          .querySelectorAll('input[name="ep-level"]')
          .forEach(function (radio) {
            radio.addEventListener("change", function () {
              state.level = this.value;
              state.disc = "";
              state.campuses = [];
              state.selectedProgName = "";
              populateDiscs();
              var sel = document.getElementById("epDiscSelect");
              if (sel) sel.value = "";
              document.querySelectorAll(".ep-campus-chk").forEach(function (c) {
                c.checked = false;
              });
              document.getElementById("epProgGroup").innerHTML = "";
              document
                .getElementById("epProgGroup")
                .classList.remove("ep-enabled");
              updateCampusAvailability();
              renderResults();
            });
          });

        var discSel = document.getElementById("epDiscSelect");
        if (discSel) {
          discSel.addEventListener("change", function () {
            state.disc = this.value;
            state.campuses = [];
            state.selectedProgName = "";
            document.querySelectorAll(".ep-campus-chk").forEach(function (c) {
              c.checked = false;
            });
            updateCampusAvailability();
            renderProgList();
            renderResults();
          });
        }

        document.querySelectorAll(".ep-campus-chk").forEach(function (chk) {
          chk.addEventListener("change", function () {
            var c = this.value;
            if (this.checked) {
              if (state.campuses.indexOf(c) === -1) state.campuses.push(c);
            } else {
              state.campuses = state.campuses.filter(function (x) {
                return x !== c;
              });
            }
            state.selectedProgName = "";
            renderProgList();
            renderResults();
          });
        });

        /* ─────────────────────────────── INIT ──────────────────────────────────── */
        populateDiscs();
        updateCampusAvailability();
        document.getElementById("epFilterCols").classList.add("ep-visible");
       var epProgGroup = document.getElementById("epProgGroup");
        if (epProgGroup) {
          epProgGroup.addEventListener("scroll", updateProgScrollHint);
          window.addEventListener("resize", updateProgScrollHint);
        }
      })();




      /* ── Stat counter animation (scroll-triggered) ── */
      (function () {
        var DURATION = 1600;

        function easeOutExpo(t) {
          return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
        }

        function formatValue(val, fmt) {
          if (fmt === "comma") return Math.round(val).toLocaleString("en-IN");
          if (fmt === "decimal1") return val.toFixed(1);
          return Math.round(val).toString();
        }

        function animateCounter(el) {
          var target = parseFloat(el.dataset.count);
          var fmt = el.dataset.format || "integer";
          var startVal = target * 0.05;
          var startTime = null;

          function step(ts) {
            if (!startTime) startTime = ts;
            var progress = Math.min((ts - startTime) / DURATION, 1);
            el.textContent = formatValue(
              startVal + (target - startVal) * easeOutExpo(progress),
              fmt,
            );
            if (progress < 1) requestAnimationFrame(step);
            else el.textContent = formatValue(target, fmt);
          }
          requestAnimationFrame(step);
        }

        var section = document.getElementById("sec-stats");
        if (!section || !("IntersectionObserver" in window)) return;

        var fired = false;
        var observer = new IntersectionObserver(
          function (entries) {
            if (fired || !entries[0].isIntersecting) return;
            fired = true;
            observer.disconnect();

            section.querySelectorAll(".why-card").forEach(function (cell, i) {
              setTimeout(function () {
                cell.classList.add("counted");
                var counter = cell.querySelector("[data-count]");
                if (counter) animateCounter(counter);
              }, i * 80);
            });
          },
          {
            threshold: 0.2,
            rootMargin: "0px 0px -60px 0px",
          },
        );

        observer.observe(section);
      })();



      /* ── GAT tab switching ── */
      (function () {
        var tabs = document.querySelectorAll("#gatTabs .gat-tab");
        var panels = document.querySelectorAll("#gatPanels .gat-panel");
        if (!tabs.length) return;

        tabs.forEach(function (tab) {
          tab.addEventListener("click", function () {
            var target = tab.dataset.tab;
            event.preventDefault(); // prevent refresh/postback
            event.stopPropagation();
            tabs.forEach(function (t) {
              t.classList.remove("gat-tab-active");
              t.setAttribute("aria-selected", "false");
            });
            panels.forEach(function (p) {
              p.classList.remove("gat-panel-active");
            });

            tab.classList.add("gat-tab-active");
            tab.setAttribute("aria-selected", "true");
            var panel = document.getElementById(target);
            if (panel) panel.classList.add("gat-panel-active");
          });
        });
      })();

      /* ── GAT FAQ accordion ── */
      (function () {
        var list = document.getElementById("gatFaqList");
        if (!list) return;
        list.addEventListener("click", function (e) {
          var btn = e.target.closest(".gat-faq-q");
          if (!btn) return;
          var item = btn.closest(".gat-faq-item");
          var isOpen = item.classList.contains("open");
          list.querySelectorAll(".gat-faq-item.open").forEach(function (i) {
            i.classList.remove("open");
            i.querySelector(".gat-faq-q").setAttribute(
              "aria-expanded",
              "false",
            );
          });
          if (!isOpen) {
            item.classList.add("open");
            btn.setAttribute("aria-expanded", "true");
          }
        });
      })();
    

    // <!-- CONTACT MODAL -->

   
      function validateForm() {
        var email = document.getElementById("txtenqemail").value.trim();
        var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!pattern.test(email)) {
          alert("Please enter a valid email address.");
          return false;
        }
        return true;
      }



      function onlyNumbers(evt) {
        var charCode = evt.which ? evt.which : evt.keyCode;

        // Allow Backspace, Delete, Tab
        if (charCode == 8 || charCode == 9 || charCode == 46) {
          return true;
        }

        // Allow only digits 0-9
        if (charCode >= 48 && charCode <= 57) {
          return true;
        }

        return false;
      }
 



      function onlyLetters(e) {
        var charCode = e.which ? e.which : e.keyCode;

        // Allow Backspace, Tab, Space
        if (charCode == 8 || charCode == 9 || charCode == 32) {
          return true;
        }

        // Allow A-Z and a-z
        if (
          (charCode >= 65 && charCode <= 90) ||
          (charCode >= 97 && charCode <= 122)
        ) {
          return true;
        }

        return false;
      }
  


      // ── Contact modal ────────────────────────────────────
      (function () {
        var backdrop = document.getElementById("contactModal");
        var form = document.getElementById("cmodalForm");
        var successEl = document.getElementById("cmodalSuccess");

        function openModal() {
          console.log("OPEN CLICKED");
          $("#lblerrmsgenquiry").text("");

          // Clear textboxes
          $("#txtenqname").val("");
          $("#txtenqquestion").val("");
          $("#txtenqmobile").val("");
          $("#txtenqemail").val("");

          // Reset dropdowns
          $("#ddlenqcampus").prop("selectedIndex", 0);
          $("#ddlenqdegree").prop("selectedIndex", 0);

          backdrop.classList.add("open");
          console.log(backdrop.className);
          document.body.style.overflow = "hidden";
        }

        function closeModal() {
          backdrop.classList.remove("open");
          document.body.style.overflow = "";
          setTimeout(function () {
            form.style.display = "";
            successEl.style.display = "none";
            form.reset && form.reset();
          }, 300);
        }

        var triggers = document.querySelectorAll(".cmodal-open-trigger");
        //triggers.forEach(function (el) {
        //  el.addEventListener("click", openModal);
        //});

        $(document).on("click", ".cmodal-open-trigger", function () {
          $("#contactModal").addClass("open");
          $("body").css("overflow", "hidden");
        });

        backdrop.addEventListener("click", function (e) {
          if (e.target === backdrop) closeModal();
        });
        document
          .getElementById("cmodalClose")
          .addEventListener("click", closeModal);
        document.addEventListener("keydown", function (e) {
          if (e.key === "Escape") closeModal();
        });

        form.addEventListener("submit", function (e) {
          e.preventDefault();
          form.style.display = "none";
          successEl.style.display = "block";
          setTimeout(closeModal, 3200);
        });

        triggers.forEach(function (el) {
          el.addEventListener("click", openModal);
        });
      })();
  


      document.querySelectorAll(".gs-watch").forEach((btn) => {
        btn.addEventListener("click", function (e) {
          e.preventDefault();

          openModal(this.dataset.title, this.dataset.info, this.dataset.video);
        });
      });

      function openModal(title, info, youtubeUrl) {
        document.getElementById("modalTitle").textContent = title;
        document.getElementById("modalInfo").textContent = info;

        const videoId = new URL(youtubeUrl).searchParams.get("v");

        document.getElementById("yt").src =
          `https://www.youtube.com/embed/${videoId}?autoplay=1`;

        document.getElementById("overlay").classList.add("open");
      }

      function closeModal() {
        document.getElementById("overlay").classList.remove("open");
        document.getElementById("yt").src = "";
      }
  



      //function toggleCities(btn) {
      //    var moreCities = document.getElementById("moreCities");

      //    if (moreCities.style.display === "none" || moreCities.style.display === "") {
      //        moreCities.style.display = "block";
      //        btn.innerHTML = "Show Less";
      //    } else {
      //        moreCities.style.display = "none";
      //        btn.innerHTML = "+ " + moreCities.children.length + " more cities";
      //    }
      //}







      
      function scrollToProgramEnd() {
        var progDiv = document.querySelector(".ep-prog-col");
        if (!progDiv) return;
        progDiv.scrollTo({
          top: progDiv.scrollHeight,
          behavior: "smooth",
        });
        return false; // prevent postback
      }
 



      /* ─────────────────────────────── RENDER RESULTS ─────────────────────────── */
      function renderResults() {
        var area = document.getElementById("epResultsArea");
        if (!area) return;
        if (!state.selectedProgName || !state.disc || !state.campuses.length) {
          if (state.disc && state.campuses.length) {
            area.innerHTML =
              '<div style="text-align: center; padding: 40px 24px; color: rgba(255, 255, 255, 0.45); font-size: 13.5px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px; font-weight: 500;">Select a programme from the list to view its fee structures, campus details, and eligibility.</div>';
          } else {
            area.innerHTML = "";
          }
          return;
        }
        var disc = DATA[state.level] && DATA[state.level][state.disc];
        if (!disc || !disc.programs[state.selectedProgName]) {
          area.innerHTML = "";
          return;
        }
        var available = getAvailableCampuses();
        var activeCampuses = state.campuses.filter(function (c) {
          return available.indexOf(c) !== -1;
        });
        area.innerHTML = buildResultBlock(
          state.selectedProgName,
          disc.programs[state.selectedProgName],
          activeCampuses,
        );
      }

      /* ─────────────────────────────── RENDER PROGRAM LIST ─────────────────────── */

  //     var CAMPUS_LABELS = {
  //       vizag: "Visakhapatnam",
  //       hyd: "Hyderabad",
  //       blr: "Bengaluru",
  //     };
  // var CAMPUS_ORDER = ["blr", "hyd", "vizag"];

      // function renderProgList() {
      //   var pg = document.getElementById("proggroup");
      //   if (!pg) return;
      //   pg.innerHTML = "";
      //   if (!state.disc) {
      //     pg.classList.remove("ep-enabled");
      //     return;
      //   }
      //   if (!state.campuses.length) {
      //     pg.classList.remove("ep-enabled");
      //     pg.innerHTML =
      //       '<span style="color:rgba(255,255,255,0.5);font-size:13px;">Select a campus to view programmes</span>';
      //     return;
      //   }
      //   var programs = getFilteredPrograms();
      //   var keys = Object.keys(programs);
      //   pg.classList.add("ep-enabled");
      //   if (!keys.length) {
      //     pg.innerHTML =
      //       '<span style="color:rgba(255,255,255,0.5);font-size:13px;">No programmes available at the selected campus(es)</span>';
      //     return;
      //   }
      //   if (state.selectedProgName && !programs[state.selectedProgName]) {
      //     state.selectedProgName = "";
      //   }

      //   CAMPUS_ORDER.forEach(function (c) {
      //     if (state.campuses.indexOf(c) === -1) return;
      //     var campusProgs = keys.filter(function (pName) {
      //       return programs[pName].campuses.indexOf(c) !== -1;
      //     });
      //     if (!campusProgs.length) return;


      //     var group = document.createElement("div");
      //     group.className = "ep-prog-campus-group";


      //     var hd = document.createElement("div");
      //     hd.className = "ep-prog-campus-hd";
      //     hd.textContent = CAMPUS_LABELS[c] || c;
      //     group.appendChild(hd);


      //     campusProgs.forEach(function (pName) {
      //       var div = document.createElement("div");
      //       div.className =
      //         "ep-prog-item" +
      //         (state.selectedProgName === pName ? " ep-active" : "");
      //       div.textContent = pName;
      //       div.setAttribute("data-name", pName);
      //       div.addEventListener("click", function () {
      //         state.selectedProgName = pName;
      //         renderProgList();
      //         renderResults();
      //         var area = document.getElementById("epResultsArea");
      //         if (area) {
      //           area.scrollIntoView({ behavior: "smooth", block: "start" });
      //         }
      //       });
      //       group.appendChild(div);
      //     });


      //     pg.appendChild(group);
      //   });


      //   updateProgScrollHint();
      //   requestAnimationFrame(updateProgScrollHint);
      // }

      // function updateProgScrollHint() {
      //   var pg = document.getElementById("proggroup");
      //   var wrap = pg && pg.closest(".ep-prog-scroll-wrap");
      //   if (!wrap || !pg) return;
      //   var hasScroll = pg.scrollHeight > pg.clientHeight + 2;
      //   var atBottom = pg.scrollTop + pg.clientHeight >= pg.scrollHeight - 8;
      //   wrap.classList.toggle("ep-has-scroll", hasScroll);
      //   wrap.classList.toggle("ep-at-bottom", hasScroll && atBottom);
      // }

      //toggleCall

      function toggleCall() {
        document.querySelector(".call-container").classList.toggle("active");
      }

      function scrollToProgramEnd() {
        var progGroup = document.getElementById("proggroup");
        var btn = document.getElementById("btnScrollMore");

        if (!progGroup) return;

        progGroup.scrollTo({
          top: progGroup.scrollHeight,
          behavior: "smooth",
        });

        // Hide immediately on button click
        if (btn) btn.style.display = "none";

        return false;
      }

      document.addEventListener("DOMContentLoaded", function () {
        function attachScrollListener() {
          var progGroup = document.getElementById("proggroup");
          var btn = document.getElementById("btnScrollMore");
          var divBtnShowMore = document.getElementById("divbtnshowmore");

          if (!progGroup || !btn) return;

          progGroup.addEventListener("scroll", function () {
            var atBottom =
              progGroup.scrollTop + progGroup.clientHeight >=
              progGroup.scrollHeight - 10;
            if (atBottom) {
              btn.style.display = "none";
              // Clear the class on the div when scrolled to bottom
              if (divBtnShowMore) {
                divBtnShowMore.className = "";
              }
            } else {
              btn.style.display = "";
              // Restore the class when not at bottom (optional)
              if (divBtnShowMore) {
                divBtnShowMore.className = "ep-prog-scroll-div";
              }
            }
          });
        }

        attachScrollListener();

        if (typeof Sys !== "undefined") {
          Sys.WebForms.PageRequestManager.getInstance().add_endRequest(
            function () {
              attachScrollListener();
            },
          );
        }
      });
 
function scrollToResults() {
    var resultsArea = document.getElementById('epResultsArea');
    if (!resultsArea) return;
    
    setTimeout(function () {
        var top = resultsArea.getBoundingClientRect().top + window.pageYOffset - 80;
        window.scrollTo({ top: top, behavior: 'smooth' });
    }, 150);
          }





         
      //iframe video script
      (function () {
        /* Track which panels have already loaded their iframe once */
        const loadedPanels = new Set();

        function initIframe(iframe) {
          if (!iframe) return;

          iframe.classList.remove("ht-iframe-ready");

          iframe.addEventListener("load", function onLoad() {
            /* 300ms delay lets YouTube finish first paint before revealing */
            setTimeout(function () {
              iframe.classList.add("ht-iframe-ready");
            }, 300);
          });

          /* If iframe already has a src and readyState is complete, reveal it */
          if (
            iframe.src &&
            iframe.contentDocument &&
            iframe.contentDocument.readyState === "complete"
          ) {
            setTimeout(function () {
              iframe.classList.add("ht-iframe-ready");
            }, 300);
          }
        }

        function reloadIframe(iframe) {
          if (!iframe) return;
          iframe.classList.remove("ht-iframe-ready");

          const src = iframe.getAttribute("src") || iframe.src;
          iframe.src = "";

          requestAnimationFrame(function () {
            requestAnimationFrame(function () {
              iframe.src = src;
            });
          });
        }

        /* Init the first active panel's iframe on page load */
        const activePanel = document.querySelector(".ht-panel.ht-panel-active");
        if (activePanel) {
          const activeIframe = activePanel.querySelector("iframe");
          if (activeIframe) {
            loadedPanels.add(activePanel.id);
            initIframe(activeIframe);
          }
        }

        document.querySelectorAll(".ht-tab").forEach(function (tab) {
          tab.addEventListener("click", function () {
            /* Find which panel this tab activates */
            const targetId =
              tab.dataset.target ||
              tab.getAttribute("href") ||
              tab.getAttribute("data-panel");

            if (targetId) {
              const panel = document.querySelector(targetId);
              if (!panel) return;

              const iframe = panel.querySelector("iframe");
              if (!iframe) return;

              if (loadedPanels.has(panel.id)) {
                /* Already loaded before — just hide and re-reveal, no src reset */
                iframe.classList.remove("ht-iframe-ready");
                setTimeout(function () {
                  iframe.classList.add("ht-iframe-ready");
                }, 100);
              } else {
                /* First time loading this panel — do a clean load */
                loadedPanels.add(panel.id);
                initIframe(iframe);
                reloadIframe(iframe);
              }
            } else {
              /* Fallback if tabs don't have data-target — your original logic,
                           but only reload the panel that is becoming visible */
              document.querySelectorAll(".ht-panel").forEach(function (panel) {
                if (!panel.classList.contains("ht-panel-active")) return;
                const iframe = panel.querySelector("iframe");
                if (!iframe) return;

                if (!loadedPanels.has(panel.id)) {
                  loadedPanels.add(panel.id);
                  initIframe(iframe);
                  reloadIframe(iframe);
                } else {
                  iframe.classList.remove("ht-iframe-ready");
                  setTimeout(function () {
                    iframe.classList.add("ht-iframe-ready");
                  }, 100);
                }
              });
            }
          });
        });
      })();

    

      (function () {
        const loadedPanels = new Set();

        // First active panel
        const activePanel = document.querySelector(
          ".ht-panel-la.ht-panel-active-la",
        );

        if (activePanel) {
          loadedPanels.add(activePanel.id);

          const iframe = activePanel.querySelector("iframe");

          if (iframe) {
            iframe.classList.add("ht-iframe-ready-la");
          }
        }

        document.querySelectorAll(".ht-tab-la").forEach(function (tab) {
          tab.addEventListener("click", function () {
            const panel = document.querySelector(
              ".ht-panel-la.ht-panel-active-la",
            );

            if (!panel) return;

            const iframe = panel.querySelector("iframe");

            if (!iframe) return;

            iframe.classList.add("ht-iframe-ready-la");

            loadedPanels.add(panel.id);
          });
        });
      })();
 
      function togglePassword() {
        var pwd = document.getElementById("txtpassword");
        var icon = document.getElementById("eyeIcon");

        if (pwd.type === "password") {
          pwd.type = "text";
          icon.classList.remove("bi-eye");
          icon.classList.add("bi-eye-slash");
        } else {
          pwd.type = "password";
          icon.classList.remove("bi-eye-slash");
          icon.classList.add("bi-eye");
        }
      }

      //video script
      (function () {
        const video = document.getElementById("heroVideo");
        if (!video) return;

        /* Force-set all required attributes via JS — Safari ignores HTML-only */
        video.muted = true;
        video.loop = true;
        video.controls = false;
        video.setAttribute("playsinline", "");
        video.setAttribute("webkit-playsinline", "");

        function tryPlay() {
          video.muted = true; /* Must re-confirm before every play() call on Safari */
          const p = video.play();
          if (p !== undefined) {
            p.catch(function (err) {
              if (err.name === "NotAllowedError") {
                unlockOnInteraction();
              }
            });
          }
        }

        function unlockOnInteraction() {
          const events = [
            "touchstart",
            "touchend",
            "click",
            "scroll",
            "keydown",
          ];

          function handler() {
            video.muted = true;
            tryPlay();
          }
          events.forEach((e) =>
            document.addEventListener(e, handler, {
              once: true,
              passive: true,
            }),
          );
        }

        /* Wait for DOM + metadata before attempting play */
        function init() {
          video.muted = true;
          video.controls = false;

          if (video.readyState >= 2) {
            tryPlay();
          } else {
            video.addEventListener("loadedmetadata", tryPlay, {
              once: true,
            });
            video.addEventListener("canplay", tryPlay, {
              once: true,
            });
          }

          /* Resume after tab switch or iOS app switch */
          document.addEventListener("visibilitychange", () => {
            if (!document.hidden && video.paused) tryPlay();
          });
          window.addEventListener("pageshow", () => {
            if (video.paused) tryPlay();
          });
        }

        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", init);
        } else {
          init();
        }
      })();

      
      $(document).ready(function () {
        console.log("country checked = ", $("#Rdbtncountry").is(":checked"));
      });

      $(document).ready(function () {
        // Register/Login
        if ($("#rdreg").is(":checked")) {
          $("#tab1").show();
          $("#tab2").hide();
        } else {
          $("#tab1").hide();
          $("#tab2").show();
        }

        // India/Foreign
        if ($("#Rdbtncountry").is(":checked")) {
          $("#divnationalmeritto").hide();
          $("#divinternationalmeritto").show();
        } else {
          $("#divnationalmeritto").show();
          $("#divinternationalmeritto").hide();
        }
      });
 
      function showLoader() {
        document.getElementById("loaderDiv").style.display = "block";
      }

      function hideLoader() {
        document.getElementById("loaderDiv").style.display = "none";
      }
  